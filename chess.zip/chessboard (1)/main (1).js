let container= toStringz("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
let content= container;
let content=